// Add your custom JavaScript code here

// Login form submission
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
  
    // Perform login validation and redirect to the dashboard page
    // For simplicity, we'll assume successful login and redirect immediately
  
    window.location.href = '/dashboard.html';
  });
  
  // Dashboard page
  if (window.location.pathname === '/dashboard.html') {
    const taskListContainer = document.getElementById('task-list');
    const addTaskBtn = document.getElementById('add-task-btn');
  }
  
    // Fetch tasks from the server or local storage
    const tasks = [];
  
    // Render task list
    function renderTaskList() {
      taskListContainer.innerHTML = '';
  
      if (tasks.length === 0) {
        taskListContainer.innerHTML = '<p>No tasks found.</p>';
        return;
      }
  
      const table = document.createElement('table');
      table.id = 'task-table';
      const thead = document.createElement('thead');
      const tbody = document.createElement('tbody');
  
      const headerRow = document.createElement('tr');
      headerRow.innerHTML = `
        <th>Title</th>
        <th>Assignee</th>
        <th>Status</th>
        <th>Actions</th>
      `;
  
      thead.appendChild(headerRow);
  
      tasks.forEach((task, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${task.title}</td>
          <td>${task.assignee}</td>
          <td>${task.status}</td>
          <td>
            <button class="edit-task-btn" data-index="${index}">Edit</button>
            <button class="delete-task-btn" data-index="${index}">Delete</button>
          </td>
        `;
        tbody.appendChild(row);
      });
  
      table.appendChild(thead);
      table.appendChild(tbody);
  
      taskListContainer.appendChild(table);
    }
  
    // Handle add task button click
    addTaskBtn.addEventListener()
