const express = require('express');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const port = 3000;

// Middleware
app.use(express.static('public'));
app.use(express.json());

// Routes

// Get all tasks
app.get('/tasks', (req, res) => {
  fs.readFile('./db.json', 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading tasks:', err);
      res.status(500).send('Internal Server Error');
    } else {
      const tasks = JSON.parse(data);
      res.json(tasks);
    }
  });
});

// Get a specific task
app.get('/tasks/:id', (req, res) => {
  const taskId = req.params.id;
  fs.readFile('./db.json', 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading tasks:', err);
      res.status(500).send('Internal Server Error');
    } else {
      const tasks = JSON.parse(data);
      const task = tasks.find(task => task.id === taskId);
      if (task) {
        res.json(task);
      } else {
        res.status(404).send('Task not found');
      }
    }
  });
});

// Create a task
app.post('/tasks', (req, res) => {
  const { title, assignee, status } = req.body;
  const newTask = {
    id: uuidv4(),
    title,
    assignee,
    status
  };
  fs.readFile('./db.json', 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading tasks:', err);
      res.status(500).send('Internal Server Error');
    } else {
      const tasks = JSON.parse(data);
      tasks.push(newTask);
      fs.writeFile('./db.json', JSON.stringify(tasks), err => {
        if (err) {
          console.error('Error writing tasks:', err);
          res.status(500).send('Internal Server Error');
        } else {
          res.status(201).json(newTask);
        }
      });
    }
  });
});

// Update a task
app.put('/tasks/:id', (req, res) => {
  const taskId = req.params.id;
  const { title, assignee, status } = req.body;
  fs.readFile('./db.json', 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading tasks:', err);
      res.status(500).send('Internal Server Error');
    } else {
      const tasks = JSON.parse(data);
      const task = tasks.find(task => task.id === taskId);
      if (task) {
        task.title = title;
        task.assignee = assignee;
        task.status = status;
        fs.writeFile('./db.json', JSON.stringify(tasks), err => {
          if (err) {
            console.error('Error writing tasks:', err);
            res.status(500).send('Internal Server Error');
          } else {
            res.status(200).json(task);
          }
        });
      } else {
        res.status(404).send('Task not found');
      }
    }
  });
});

// Delete a task
app.delete('/tasks/:id', (req, res) => {
  const taskId = req.params.id;
  fs.readFile('./db.json', 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading tasks:', err);
      res.status(500).send('Internal Server Error');
    } else {
      let tasks = JSON.parse(data);
      const filteredTasks = tasks.filter(task => task.id !== taskId);
      if (filteredTasks.length === tasks.length) {
        res.status(404).send('Task not found');
      } else {
        tasks = filteredTasks;
        fs.writeFile('./db.json', JSON.stringify(tasks), err => {
          if (err) {
            console.error('Error writing tasks:', err);
            res.status(500).send('Internal Server Error');
          } else {
            res.status(200).send('Task deleted successfully');
          }
        });
      }
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});