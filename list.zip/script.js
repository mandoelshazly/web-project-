// Add your custom JavaScript code here

// Login form submission
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
  
    // Perform login validation and redirect to the desired page
  });
  
  // Example dynamic data for the task list
  const tasks = [
    { title: 'Task 1', dueDate: '2022-01-01', status: 'In Progress' },
    { title: 'Task 2', dueDate: '2022-01-05', status: 'Completed' },
    { title: 'Task 3', dueDate: '2022-01-10', status: 'Pending' }
  ];
  
  // Generate task table rows dynamically
  const taskTable = document.getElementById('task-table');
  const tbody = taskTable.getElementsByTagName('tbody')[0];
  tasks.forEach(task => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${task.title}</td>
      <td>${task.dueDate}</td>
      <td>${task.status}</td>
    `;
    tbody.appendChild(row);
  });
  
  // Example static user profile information
  const profileInfo = document.getElementById('profile-info');
  profileInfo.innerHTML = `
    <h2>mando elshazly</h2>
    <p>Email: mando@gmail.com</p>
    <p>Role: Administrator</p>
  `;