function checkaction(checkbox){

    if(checkbox.checked){
        document.getElementById("signup").disabled = false

    }
    else{
        document.getElementById("signup").disabled = true
    }
}



function validate(){

    var name = document.getElementById("name").value ;
    var pass = document.getElementById("password").value ;
    var email = document.getElementById("email").value ;
    var conpass = document.getElementById("conpass").value ;

    if(!name || !pass || !email || ! conpass){
        alert("some Fields are Empty");
    
    }else{
   
        window.location.href ="main page.html";
        
        alert("Signed Up Successfully :)");
        

    }function validateEmail(email) {
        var parts = email.split("@");
        
        if (parts.length !== 2) {
          
          return false;
        } else {
     
        return true;

      }
      
    }


    return true;
}
