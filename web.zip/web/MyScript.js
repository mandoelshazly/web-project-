function checkaction(checkbox){

    if(checkbox.checked){
        document.getElementById("signup").disabled = false

    }
    else{
        document.getElementById("signup").disabled = true
    }
}



function validate(){

    var name = document.getElementById("name").value ;
    var pass = document.getElementById("password").value ;

    if(!name || !pass ){
        alert("some Fields are Empty");
    
    }else{
   
        window.location.href ="main page.html";
        
        alert("Signed Up Successfully :)");
        

    }

    return true;
}

